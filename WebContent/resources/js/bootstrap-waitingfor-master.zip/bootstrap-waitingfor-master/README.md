bootstrap-waitingfor
====================

"Waiting for..." modal dialog with progress bar for Bootstrap
